export declare class WinstonLoggerModule {
}
