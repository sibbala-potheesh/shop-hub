"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.stream = exports.logger = exports.WinstonLogger = void 0;
const common_1 = require("@nestjs/common");
const winston = require("winston");
const DailyRotateFile = require('winston-daily-rotate-file');
const logLevels = {
    error: 0,
    warn: 1,
    info: 2,
    http: 3,
    verbose: 4,
    debug: 5,
    silly: 6,
};
const logColors = {
    error: 'red',
    warn: 'yellow',
    info: 'green',
    http: 'magenta',
    verbose: 'cyan',
    debug: 'blue',
    silly: 'grey',
};
winston.addColors(logColors);
const consoleFormat = winston.format.combine(winston.format.timestamp({ format: 'YYYY-MM-DD HH:mm:ss' }), winston.format.colorize({ all: true }), winston.format.printf(({ timestamp, level, message, context, trace, ...meta }) => {
    let output = `${timestamp} [${level}]`;
    if (context)
        output += ` [${context}]`;
    output += ` ${message}`;
    if (Object.keys(meta).length) {
        output += ` ${JSON.stringify(meta)}`;
    }
    if (trace) {
        output += `\n${trace}`;
    }
    return output;
}));
const fileFormat = winston.format.combine(winston.format.timestamp({ format: 'YYYY-MM-DD HH:mm:ss' }), winston.format.errors({ stack: true }), winston.format.json());
let WinstonLogger = class WinstonLogger {
    constructor() {
        const environment = process.env.NODE_ENV || 'development';
        const consoleLevel = environment === 'production' ? 'info' : 'debug';
        const transports = [
            new winston.transports.Console({
                level: consoleLevel,
                format: consoleFormat,
            }),
            new DailyRotateFile({
                filename: 'logs/application-%DATE%.log',
                datePattern: 'YYYY-MM-DD',
                zippedArchive: true,
                maxSize: '20m',
                maxFiles: '14d',
                format: fileFormat,
                level: 'info',
            }),
            new DailyRotateFile({
                filename: 'logs/error-%DATE%.log',
                datePattern: 'YYYY-MM-DD',
                zippedArchive: true,
                maxSize: '20m',
                maxFiles: '30d',
                format: fileFormat,
                level: 'error',
            }),
        ];
        this.logger = winston.createLogger({
            levels: logLevels,
            format: fileFormat,
            transports,
            exitOnError: false,
        });
    }
    log(message, context) {
        this.logger.info(message, { context });
    }
    error(message, trace, context) {
        this.logger.error(message, { trace, context });
    }
    warn(message, context) {
        this.logger.warn(message, { context });
    }
    debug(message, context) {
        this.logger.debug(message, { context });
    }
    verbose(message, context) {
        this.logger.verbose(message, { context });
    }
    http(message, context) {
        this.logger.http(message, { context });
    }
};
exports.WinstonLogger = WinstonLogger;
exports.WinstonLogger = WinstonLogger = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [])
], WinstonLogger);
exports.logger = winston.createLogger({
    levels: logLevels,
    format: fileFormat,
    transports: [
        new winston.transports.Console({ format: consoleFormat }),
        new DailyRotateFile({
            filename: 'logs/application-%DATE%.log',
            datePattern: 'YYYY-MM-DD',
            zippedArchive: true,
            maxSize: '20m',
            maxFiles: '14d',
            format: fileFormat,
            level: 'info',
        }),
        new DailyRotateFile({
            filename: 'logs/error-%DATE%.log',
            datePattern: 'YYYY-MM-DD',
            zippedArchive: true,
            maxSize: '20m',
            maxFiles: '30d',
            format: fileFormat,
            level: 'error',
        }),
    ],
});
exports.stream = {
    write: (msg) => exports.logger.http(msg.trim()),
};
//# sourceMappingURL=winston-logger.service.js.map