import { LoggerService } from '@nestjs/common';
import * as winston from 'winston';
export declare class WinstonLogger implements LoggerService {
    private readonly logger;
    constructor();
    log(message: any, context?: string): void;
    error(message: any, trace?: string, context?: string): void;
    warn(message: any, context?: string): void;
    debug(message: any, context?: string): void;
    verbose(message: any, context?: string): void;
    http(message: any, context?: string): void;
}
export declare const logger: winston.Logger;
export declare const stream: {
    write: (msg: string) => winston.Logger;
};
