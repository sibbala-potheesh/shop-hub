export declare const DEFAULT_PAGE = 1;
export declare const DEFAULT_LIMIT = 10;
