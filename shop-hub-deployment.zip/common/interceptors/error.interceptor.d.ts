import { NestInterceptor, ExecutionContext, CallHandler } from '@nestjs/common';
import { Observable } from 'rxjs';
import { WinstonLogger } from '../logger/winston-logger.service';
export declare class ErrorInterceptor implements NestInterceptor {
    private readonly logger;
    constructor(logger: WinstonLogger);
    intercept(context: ExecutionContext, next: CallHandler): Observable<any>;
}
