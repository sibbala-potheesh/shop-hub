export declare class PaginationDto {
    page?: number | string;
    limit?: number | string;
}
