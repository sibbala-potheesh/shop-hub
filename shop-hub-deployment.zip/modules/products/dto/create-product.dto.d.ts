declare class VariantDto {
    type: string;
    name: string;
    options: string[];
}
export declare class CreateProductDto {
    title: string;
    description?: string;
    price: number;
    images?: string[];
    category?: string;
    stock: number;
    variants?: VariantDto[];
    rating?: number;
    reviews?: number;
}
export {};
