export declare class ListProductsDto {
    page?: number | string;
    limit?: number | string;
    category?: string;
    minPrice?: number | string;
    maxPrice?: number | string;
    q?: string;
}
