import { Document, Types } from 'mongoose';
export type ProductDocument = Product & Document;
declare class Variant {
    type: string;
    name: string;
    options: string[];
}
export declare class Product {
    title: string;
    description?: string;
    price: number;
    images?: string[];
    category?: string;
    stock: number;
    variants?: Variant[];
    rating?: number;
    reviews?: number;
}
export declare const ProductSchema: import("mongoose").Schema<Product, import("mongoose").Model<Product, any, any, any, Document<unknown, any, Product> & Product & {
    _id: Types.ObjectId;
}, any>, {}, {}, {}, {}, import("mongoose").DefaultSchemaOptions, Product, Document<unknown, {}, import("mongoose").FlatRecord<Product>> & import("mongoose").FlatRecord<Product> & {
    _id: Types.ObjectId;
}>;
export {};
