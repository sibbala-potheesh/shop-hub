import { Model, Types } from 'mongoose';
import { Address, AddressDocument } from './schemas/address.schema';
import { CreateAddressDto } from './dto/create-address.dto';
import { UpdateAddressDto } from './dto/update-address.dto';
export declare class AddressService {
    private addrModel;
    constructor(addrModel: Model<AddressDocument>);
    create(dto: CreateAddressDto, ownerId: string): Promise<import("mongoose").Document<unknown, {}, AddressDocument> & Address & import("mongoose").Document<any, any, any> & {
        _id: Types.ObjectId;
    }>;
    list(query: any, user: any, isAdmin: boolean, page?: number, limit?: number): Promise<{
        items: (import("mongoose").Document<unknown, {}, AddressDocument> & Address & import("mongoose").Document<any, any, any> & {
            _id: Types.ObjectId;
        })[];
        total: number;
        page: number;
        limit: number;
    }>;
    findOne(id: string, user: any, isAdmin: boolean): Promise<import("mongoose").Document<unknown, {}, AddressDocument> & Address & import("mongoose").Document<any, any, any> & {
        _id: Types.ObjectId;
    }>;
    update(id: string, dto: UpdateAddressDto, user: any, isAdmin: boolean): Promise<import("mongoose").Document<unknown, {}, AddressDocument> & Address & import("mongoose").Document<any, any, any> & {
        _id: Types.ObjectId;
    }>;
    remove(id: string, user: any, isAdmin: boolean): Promise<import("mongoose").Document<unknown, {}, AddressDocument> & Address & import("mongoose").Document<any, any, any> & {
        _id: Types.ObjectId;
    }>;
}
