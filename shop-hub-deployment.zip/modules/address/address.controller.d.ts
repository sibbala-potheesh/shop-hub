import { AddressService } from './address.service';
import { CreateAddressDto } from './dto/create-address.dto';
import { UpdateAddressDto } from './dto/update-address.dto';
export declare class AddressController {
    private readonly addressService;
    constructor(addressService: AddressService);
    create(dto: CreateAddressDto, req: any): Promise<import("mongoose").Document<unknown, {}, import("./schemas/address.schema").AddressDocument> & import("./schemas/address.schema").Address & import("mongoose").Document<any, any, any> & {
        _id: import("mongoose").Types.ObjectId;
    }>;
    list(req: any, page?: string, limit?: string, city?: string, country?: string): Promise<{
        items: (import("mongoose").Document<unknown, {}, import("./schemas/address.schema").AddressDocument> & import("./schemas/address.schema").Address & import("mongoose").Document<any, any, any> & {
            _id: import("mongoose").Types.ObjectId;
        })[];
        total: number;
        page: number;
        limit: number;
    }>;
    get(id: string, req: any): Promise<import("mongoose").Document<unknown, {}, import("./schemas/address.schema").AddressDocument> & import("./schemas/address.schema").Address & import("mongoose").Document<any, any, any> & {
        _id: import("mongoose").Types.ObjectId;
    }>;
    update(id: string, dto: UpdateAddressDto, req: any): Promise<import("mongoose").Document<unknown, {}, import("./schemas/address.schema").AddressDocument> & import("./schemas/address.schema").Address & import("mongoose").Document<any, any, any> & {
        _id: import("mongoose").Types.ObjectId;
    }>;
    remove(id: string, req: any): Promise<import("mongoose").Document<unknown, {}, import("./schemas/address.schema").AddressDocument> & import("./schemas/address.schema").Address & import("mongoose").Document<any, any, any> & {
        _id: import("mongoose").Types.ObjectId;
    }>;
}
