import { Document, Types } from 'mongoose';
export type AddressDocument = Address & Document;
export declare class Address {
    firstName: string;
    lastName: string;
    address: string;
    city: string;
    state?: string;
    zipcode: string;
    country: string;
    phoneNumber: string;
    isDefault: boolean;
    owner: Types.ObjectId;
}
export declare const AddressSchema: import("mongoose").Schema<Address, import("mongoose").Model<Address, any, any, any, Document<unknown, any, Address> & Address & {
    _id: Types.ObjectId;
}, any>, {}, {}, {}, {}, import("mongoose").DefaultSchemaOptions, Address, Document<unknown, {}, import("mongoose").FlatRecord<Address>> & import("mongoose").FlatRecord<Address> & {
    _id: Types.ObjectId;
}>;
