export declare class CreateAddressDto {
    firstName: string;
    lastName: string;
    address: string;
    city: string;
    state?: string;
    zipcode: string;
    country: string;
    phoneNumber: string;
    isDefault?: boolean;
}
