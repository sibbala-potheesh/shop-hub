import { AuthService } from './auth.service';
import type { Response } from 'express';
import { UsersService } from '../users/users.service';
import { CreateUserDto } from '../users/dto/create-user.dto';
import { LoginDto } from '../users/dto/login.dto';
export declare class AuthController {
    private authService;
    private usersService;
    constructor(authService: AuthService, usersService: UsersService);
    register(dto: CreateUserDto): Promise<any>;
    login(dto: LoginDto): Promise<{
        token: {
            access_token: string;
            expires_in: string;
        };
        user: any;
    }>;
    profile(req: any): Promise<any>;
    googleAuth(): Promise<void>;
    googleTokenAuth(req: any): Promise<{
        token: {
            access_token: string;
            expires_in: string;
        };
        user: any;
    }>;
    googleAuthRedirect(req: any, res: Response): Promise<void>;
}
