"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.GoogleTokenStrategy = void 0;
const common_1 = require("@nestjs/common");
const passport_1 = require("@nestjs/passport");
const passport_custom_1 = require("passport-custom");
const google_auth_library_1 = require("google-auth-library");
let GoogleTokenStrategy = class GoogleTokenStrategy extends (0, passport_1.PassportStrategy)(passport_custom_1.Strategy, 'google-token') {
    constructor() {
        super();
        this.client = new google_auth_library_1.OAuth2Client(process.env.GOOGLE_CLIENT_ID || '');
    }
    async validate(req) {
        const idToken = req.body?.idToken || req.headers['x-id-token'] || req.query?.idToken;
        if (!idToken) {
            throw new common_1.UnauthorizedException('No ID token provided');
        }
        const ticket = await this.client.verifyIdToken({
            idToken,
            audience: process.env.GOOGLE_CLIENT_ID || '',
        });
        const payload = ticket.getPayload();
        if (!payload || !payload.email) {
            throw new common_1.UnauthorizedException('Invalid ID token');
        }
        return {
            provider: 'google',
            providerId: payload['sub'],
            email: payload['email'],
            displayName: payload['name'],
            firstName: payload['given_name'],
            lastName: payload['family_name'],
            photo: payload['picture'],
            rawPayload: payload,
        };
    }
};
exports.GoogleTokenStrategy = GoogleTokenStrategy;
exports.GoogleTokenStrategy = GoogleTokenStrategy = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [])
], GoogleTokenStrategy);
//# sourceMappingURL=google-token.strategy.js.map