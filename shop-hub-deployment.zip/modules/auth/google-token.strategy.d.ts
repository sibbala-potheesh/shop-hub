import { Strategy } from 'passport-custom';
declare const GoogleTokenStrategy_base: new (...args: any[]) => Strategy;
export declare class GoogleTokenStrategy extends GoogleTokenStrategy_base {
    private client;
    constructor();
    validate(req: any): Promise<{
        provider: string;
        providerId: string;
        email: string;
        displayName: string | undefined;
        firstName: string | undefined;
        lastName: string | undefined;
        photo: string | undefined;
        rawPayload: import("google-auth-library").TokenPayload;
    }>;
}
export {};
