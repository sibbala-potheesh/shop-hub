"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AuthController = void 0;
const common_1 = require("@nestjs/common");
const auth_service_1 = require("./auth.service");
const swagger_1 = require("@nestjs/swagger");
const jwt_auth_guard_1 = require("./guards/jwt-auth.guard");
const passport_1 = require("@nestjs/passport");
const users_service_1 = require("../users/users.service");
const create_user_dto_1 = require("../users/dto/create-user.dto");
const login_dto_1 = require("../users/dto/login.dto");
const public_decorator_1 = require("../../common/decorators/public.decorator");
let AuthController = class AuthController {
    constructor(authService, usersService) {
        this.authService = authService;
        this.usersService = usersService;
    }
    async register(dto) {
        const salt = parseInt(process.env.BCRYPT_SALT_ROUNDS || '10', 10);
        const user = await this.usersService.create(dto, salt);
        const { password, ...safe } = user;
        return safe;
    }
    async login(dto) {
        const user = await this.usersService.findByEmail(dto.email);
        if (!user)
            throw new common_1.BadRequestException('Invalid credentials');
        const valid = await this.authService.validateUser(dto.email, dto.password);
        if (!valid)
            throw new common_1.BadRequestException('Invalid credentials');
        const token = await this.authService.login(user);
        const userObj = user.toJSON
            ? user.toJSON()
            : { ...user };
        delete userObj.password;
        userObj.id = userObj._id ? userObj._id.toString() : userObj.id;
        return { token, user: userObj };
    }
    async profile(req) {
        const userId = req.user.userId;
        const user = await this.usersService.findById(userId);
        if (!user)
            throw new common_1.BadRequestException('User not found');
        const { password, ...safe } = user;
        return safe;
    }
    async googleAuth() { }
    async googleTokenAuth(req) {
        return this.authService.googleLogin(req.user);
    }
    async googleAuthRedirect(req, res) {
        const gUser = req.user;
        if (!gUser || !gUser.emails || !gUser.emails.length) {
            throw new common_1.BadRequestException('No email found from Google account');
        }
        const email = gUser.emails[0].value;
        let user = await this.usersService.findByEmail(email);
        console.log('Google OAuth2 callback user email:', user);
        if (!user) {
            const dto = {
                email,
                firstName: gUser.displayName || gUser.name?.givenName || 'Google User',
                password: Math.random().toString(36).slice(-8),
            };
            const salt = parseInt(process.env.BCRYPT_SALT_ROUNDS || '10', 10);
            user = await this.usersService.create(dto, salt);
        }
        const token = await this.authService.login(user);
        const rawUser = typeof user.toJSON === 'function'
            ? user.toJSON()
            : user && user._doc
                ? user._doc
                : { ...user };
        delete rawUser.password;
        delete rawUser.__v;
        delete rawUser.$__;
        delete rawUser.$isNew;
        delete rawUser.__t;
        const id = rawUser._id ? String(rawUser._id) : rawUser.id ?? undefined;
        rawUser.id = id;
        delete rawUser._id;
        const accessToken = token && typeof token === 'object' && token.access_token
            ? token.access_token
            : typeof token === 'string'
                ? token
                : token?.access_token ?? null;
        const frontendUrl = process.env.FRONTEND_URL || 'http://localhost:3000';
        return res.redirect(`${frontendUrl}/auth/success?token=${encodeURIComponent(accessToken)}&userId=${encodeURIComponent(rawUser.id ?? '')}`);
    }
};
exports.AuthController = AuthController;
__decorate([
    (0, common_1.Post)('register'),
    (0, swagger_1.ApiOperation)({ summary: 'Register a new user' }),
    (0, swagger_1.ApiResponse)({ status: 201, description: 'User created' }),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [create_user_dto_1.CreateUserDto]),
    __metadata("design:returntype", Promise)
], AuthController.prototype, "register", null);
__decorate([
    (0, common_1.Post)('login'),
    (0, swagger_1.ApiOperation)({ summary: 'Login user and get JWT' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: 'Returns access token' }),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [login_dto_1.LoginDto]),
    __metadata("design:returntype", Promise)
], AuthController.prototype, "login", null);
__decorate([
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard),
    (0, swagger_1.ApiBearerAuth)(),
    (0, common_1.Get)('profile'),
    (0, swagger_1.ApiOperation)({ summary: 'Get profile for authenticated user' }),
    __param(0, (0, common_1.Request)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], AuthController.prototype, "profile", null);
__decorate([
    (0, public_decorator_1.Public)(),
    (0, common_1.Get)('google'),
    (0, common_1.UseGuards)((0, passport_1.AuthGuard)('google')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], AuthController.prototype, "googleAuth", null);
__decorate([
    (0, public_decorator_1.Public)(),
    (0, common_1.Post)('google/callback'),
    (0, common_1.UseGuards)((0, passport_1.AuthGuard)('google-token')),
    (0, swagger_1.ApiOperation)({ summary: 'Verify Google ID token and authenticate user' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: 'User authenticated successfully' }),
    (0, swagger_1.ApiResponse)({
        status: 401,
        description: 'Invalid token or authentication failed',
    }),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    __param(0, (0, common_1.Req)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], AuthController.prototype, "googleTokenAuth", null);
__decorate([
    (0, common_1.Get)('google/callback'),
    (0, common_1.UseGuards)((0, passport_1.AuthGuard)('google')),
    (0, swagger_1.ApiOperation)({ summary: 'Google OAuth2 callback' }),
    __param(0, (0, common_1.Request)()),
    __param(1, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], AuthController.prototype, "googleAuthRedirect", null);
exports.AuthController = AuthController = __decorate([
    (0, swagger_1.ApiTags)('auth'),
    (0, common_1.Controller)('auth'),
    __metadata("design:paramtypes", [auth_service_1.AuthService,
        users_service_1.UsersService])
], AuthController);
//# sourceMappingURL=auth.controller.js.map