"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.OrdersService = void 0;
const common_1 = require("@nestjs/common");
const mongoose_1 = require("@nestjs/mongoose");
const order_schema_1 = require("./schemas/order.schema");
const mongoose_2 = require("mongoose");
const products_service_1 = require("../products/products.service");
const mongoose_3 = require("@nestjs/mongoose");
const mongoose_4 = require("mongoose");
let OrdersService = class OrdersService {
    constructor(orderModel, productsService, connection) {
        this.orderModel = orderModel;
        this.productsService = productsService;
        this.connection = connection;
    }
    round2(n) {
        return Math.round(n * 100) / 100;
    }
    async create(dto, userId) {
        if (!dto.items || dto.items.length === 0) {
            throw new common_1.BadRequestException('Items cannot be empty');
        }
        const subtotal = this.round2(dto.items.reduce((s, it) => s + it.price * it.quantity, 0));
        const shipping = typeof dto.shipping === 'number' ? dto.shipping : 15;
        const tax = typeof dto.tax === 'number' ? dto.tax : this.round2(subtotal * 0.1);
        const total = this.round2(subtotal + shipping + tax);
        const session = await this.connection.startSession();
        session.startTransaction();
        try {
            for (const it of dto.items) {
                await this.productsService.decrementStock(it.productId, it.quantity, session);
            }
            const order = new this.orderModel({
                contact: dto.contact,
                shippingAddress: dto.shippingAddress,
                paymentMethod: dto.paymentMethod,
                items: dto.items.map((it) => ({
                    productId: new mongoose_4.Types.ObjectId(it.productId),
                    title: it.title,
                    price: it.price,
                    quantity: it.quantity,
                })),
                subtotal,
                shipping,
                tax,
                total,
                user: new mongoose_4.Types.ObjectId(userId),
            });
            await order.save({ session });
            await session.commitTransaction();
            session.endSession();
            return order;
        }
        catch (err) {
            await session.abortTransaction();
            session.endSession();
            throw err;
        }
    }
    async list(query, user, isAdmin, page = 1, limit = 10) {
        const filter = {};
        if (!isAdmin)
            filter.user = user.userId;
        if (query.status)
            filter.status = query.status;
        if (query.email)
            filter['contact.email'] = query.email;
        const skip = (page - 1) * limit;
        const [items, total] = await Promise.all([
            this.orderModel.find(filter).skip(skip).limit(limit).exec(),
            this.orderModel.countDocuments(filter).exec(),
        ]);
        return { items, total, page, limit };
    }
    async findOne(id, user, isAdmin) {
        const order = await this.orderModel.findById(id).exec();
        if (!order)
            throw new common_1.NotFoundException('Order not found');
        if (!isAdmin && order.user.toString() !== user.userId) {
            throw new common_1.ForbiddenException('Not owner');
        }
        return order;
    }
    async updateStatus(id, status, user, isAdmin) {
        const order = await this.orderModel.findById(id).exec();
        if (!order)
            throw new common_1.NotFoundException('Order not found');
        if (!isAdmin && order.user.toString() !== user.userId) {
            throw new common_1.ForbiddenException('Not allowed to update status');
        }
        const allowed = [
            'pending',
            'processing',
            'shipped',
            'delivered',
            'cancelled',
        ];
        if (!allowed.includes(status)) {
            throw new common_1.BadRequestException('Invalid status');
        }
        order.status = status;
        return order.save();
    }
    async remove(id, user, isAdmin) {
        const order = await this.orderModel.findById(id).exec();
        if (!order)
            throw new common_1.NotFoundException('Order not found');
        if (!isAdmin && order.user.toString() !== user.userId) {
            throw new common_1.ForbiddenException('Not allowed to delete');
        }
        if (!['pending', 'cancelled'].includes(order.status)) {
            throw new common_1.BadRequestException('Only pending or cancelled orders can be deleted');
        }
        return order.deleteOne();
    }
};
exports.OrdersService = OrdersService;
exports.OrdersService = OrdersService = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, mongoose_1.InjectModel)(order_schema_1.Order.name)),
    __param(2, (0, mongoose_3.InjectConnection)()),
    __metadata("design:paramtypes", [mongoose_2.Model,
        products_service_1.ProductsService,
        mongoose_2.Connection])
], OrdersService);
//# sourceMappingURL=orders.service.js.map