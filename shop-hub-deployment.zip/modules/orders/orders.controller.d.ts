import { OrdersService } from './orders.service';
import { CreateOrderDto } from './dto/create-order.dto';
import { UpdateOrderStatusDto } from './dto/update-order-status.dto';
import { ListOrdersDto } from './dto/list-orders.dto';
export declare class OrdersController {
    private readonly ordersService;
    constructor(ordersService: OrdersService);
    create(dto: CreateOrderDto, req: any): Promise<import("mongoose").Document<unknown, {}, import("./schemas/order.schema").OrderDocument> & import("./schemas/order.schema").Order & import("mongoose").Document<any, any, any> & {
        _id: import("mongoose").Types.ObjectId;
    }>;
    list(query: ListOrdersDto, req: any): Promise<{
        items: (import("mongoose").Document<unknown, {}, import("./schemas/order.schema").OrderDocument> & import("./schemas/order.schema").Order & import("mongoose").Document<any, any, any> & {
            _id: import("mongoose").Types.ObjectId;
        })[];
        total: number;
        page: number;
        limit: number;
    }>;
    get(id: string, req: any): Promise<import("mongoose").Document<unknown, {}, import("./schemas/order.schema").OrderDocument> & import("./schemas/order.schema").Order & import("mongoose").Document<any, any, any> & {
        _id: import("mongoose").Types.ObjectId;
    }>;
    updateStatus(id: string, dto: UpdateOrderStatusDto, req: any): Promise<import("mongoose").Document<unknown, {}, import("./schemas/order.schema").OrderDocument> & import("./schemas/order.schema").Order & import("mongoose").Document<any, any, any> & {
        _id: import("mongoose").Types.ObjectId;
    }>;
    remove(id: string, req: any): Promise<import("mongoose").Document<unknown, {}, import("./schemas/order.schema").OrderDocument> & import("./schemas/order.schema").Order & import("mongoose").Document<any, any, any> & {
        _id: import("mongoose").Types.ObjectId;
    }>;
}
