import { Document, Types } from 'mongoose';
export type OrderDocument = Order & Document;
declare class Contact {
    email: string;
}
declare class ShippingAddress {
    firstName: string;
    lastName: string;
    address: string;
    city: string;
    state?: string;
    zipcode: string;
    country: string;
    phoneNumber: string;
}
declare class Item {
    productId: Types.ObjectId;
    title: string;
    price: number;
    quantity: number;
}
export type PaymentMethod = 'CreditCard' | 'PayPal' | 'ApplePay' | 'GooglePay';
export type OrderStatus = 'pending' | 'processing' | 'shipped' | 'delivered' | 'cancelled';
export declare class Order {
    contact: Contact;
    shippingAddress: ShippingAddress;
    paymentMethod: PaymentMethod;
    items: Item[];
    subtotal: number;
    shipping: number;
    tax: number;
    total: number;
    status: OrderStatus;
    user: Types.ObjectId;
}
export declare const OrderSchema: import("mongoose").Schema<Order, import("mongoose").Model<Order, any, any, any, Document<unknown, any, Order> & Order & {
    _id: Types.ObjectId;
}, any>, {}, {}, {}, {}, import("mongoose").DefaultSchemaOptions, Order, Document<unknown, {}, import("mongoose").FlatRecord<Order>> & import("mongoose").FlatRecord<Order> & {
    _id: Types.ObjectId;
}>;
export {};
