import { Order, OrderDocument } from './schemas/order.schema';
import { Model, Connection } from 'mongoose';
import { CreateOrderDto } from './dto/create-order.dto';
import { ProductsService } from '../products/products.service';
import { Types } from 'mongoose';
export declare class OrdersService {
    private orderModel;
    private productsService;
    private readonly connection;
    constructor(orderModel: Model<OrderDocument>, productsService: ProductsService, connection: Connection);
    private round2;
    create(dto: CreateOrderDto, userId: string): Promise<import("mongoose").Document<unknown, {}, OrderDocument> & Order & import("mongoose").Document<any, any, any> & {
        _id: Types.ObjectId;
    }>;
    list(query: any, user: any, isAdmin: boolean, page?: number, limit?: number): Promise<{
        items: (import("mongoose").Document<unknown, {}, OrderDocument> & Order & import("mongoose").Document<any, any, any> & {
            _id: Types.ObjectId;
        })[];
        total: number;
        page: number;
        limit: number;
    }>;
    findOne(id: string, user: any, isAdmin: boolean): Promise<import("mongoose").Document<unknown, {}, OrderDocument> & Order & import("mongoose").Document<any, any, any> & {
        _id: Types.ObjectId;
    }>;
    updateStatus(id: string, status: string, user: any, isAdmin: boolean): Promise<import("mongoose").Document<unknown, {}, OrderDocument> & Order & import("mongoose").Document<any, any, any> & {
        _id: Types.ObjectId;
    }>;
    remove(id: string, user: any, isAdmin: boolean): Promise<import("mongoose").Document<unknown, {}, OrderDocument> & Order & import("mongoose").Document<any, any, any> & {
        _id: Types.ObjectId;
    }>;
}
