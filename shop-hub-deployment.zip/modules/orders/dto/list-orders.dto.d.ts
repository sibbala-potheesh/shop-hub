export declare class ListOrdersDto {
    page?: number | string;
    limit?: number | string;
    status?: string;
    email?: string;
}
