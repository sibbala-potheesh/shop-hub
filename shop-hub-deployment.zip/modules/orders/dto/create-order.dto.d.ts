declare class ContactDto {
    email: string;
}
declare class ShippingAddressDto {
    firstName: string;
    lastName: string;
    address: string;
    city: string;
    zipcode: string;
    country: string;
    phoneNumber: string;
}
declare class ItemDto {
    productId: string;
    title: string;
    price: number;
    quantity: number;
}
export declare class CreateOrderDto {
    contact: ContactDto;
    shippingAddress: ShippingAddressDto;
    paymentMethod: 'CreditCard' | 'PayPal' | 'ApplePay' | 'GooglePay';
    items: ItemDto[];
    subtotal?: number;
    shipping?: number;
    tax?: number;
}
export {};
