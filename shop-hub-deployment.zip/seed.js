"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const core_1 = require("@nestjs/core");
const app_module_1 = require("./app.module");
const winston_logger_service_1 = require("./common/logger/winston-logger.service");
const products_service_1 = require("./modules/products/products.service");
const users_service_1 = require("./modules/users/users.service");
const dotenv = require("dotenv");
const axios_1 = require("axios");
dotenv.config();
const DUMMY_PRODUCTS_URL = process.env.DUMMY_PRODUCTS_URL || 'https://dummyjson.com/products?limit=100';
const TARGET_COUNT = 500;
const BATCH_SIZE = 20;
function mapDummyToCreateDto(dummy, variationIndex = 0) {
    const title = dummy.title || dummy.name || `Product ${dummy.id ?? ''}`;
    const description = dummy.description || dummy.body || 'No description';
    const basePrice = typeof dummy.price === 'number'
        ? dummy.price
        : parseFloat(dummy.price) || 10;
    const price = +(basePrice * (1 + (variationIndex % 7) * 0.01)).toFixed(2);
    const stock = Math.max(0, (dummy.stock ?? dummy.rating ?? 10) + (variationIndex % 20) - 5);
    const images = Array.isArray(dummy.images) && dummy.images.length > 0
        ? dummy.images
        : dummy.thumbnail
            ? [dummy.thumbnail]
            : [
                'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=800&q=80',
            ];
    const category = dummy.category || 'General';
    const variants = dummy.variants ??
        (dummy.color || dummy.colors
            ? [
                {
                    type: 'color',
                    name: 'Color',
                    options: Array.isArray(dummy.colors)
                        ? dummy.colors
                        : [dummy.color].filter(Boolean),
                },
            ]
            : []);
    const rating = typeof dummy.rating === 'number'
        ? dummy.rating
        : +(Math.random() * 5).toFixed(1);
    const reviews = typeof dummy.reviews === 'number'
        ? dummy.reviews
        : Math.floor(Math.random() * 500);
    return {
        title,
        description,
        price,
        images,
        category,
        stock,
        variants,
        rating,
        reviews,
    };
}
async function fetchDummyProducts() {
    try {
        const res = await axios_1.default.get(DUMMY_PRODUCTS_URL, { timeout: 20000 });
        if (Array.isArray(res.data))
            return res.data;
        if (Array.isArray(res.data.products))
            return res.data.products;
        return [res.data];
    }
    catch (err) {
        console.error('Failed to fetch dummy products:', err?.message || err);
        return [];
    }
}
async function batchInsert(productsService, items) {
    for (let i = 0; i < items.length; i += BATCH_SIZE) {
        const chunk = items.slice(i, i + BATCH_SIZE);
        await Promise.all(chunk.map(async (p) => {
            try {
                await productsService.create(p);
            }
            catch (e) {
                console.error(`Failed to create product ${p.title}:`, e?.message ?? e);
            }
        }));
    }
}
async function seed() {
    const app = await core_1.NestFactory.createApplicationContext(app_module_1.AppModule, {
        logger: false,
    });
    const logger = app.get(winston_logger_service_1.WinstonLogger);
    const productsService = app.get(products_service_1.ProductsService);
    const usersService = app.get(users_service_1.UsersService);
    try {
        const products = await productsService.list({}, 1, 1);
        if (products.total === 0) {
            logger.log('No products found — fetching dummy products to seed...');
            const dummy = await fetchDummyProducts();
            if (dummy.length === 0) {
                logger.error('No dummy products available. Exiting seed.');
            }
            else {
                const mapped = [];
                let idx = 0;
                while (mapped.length < TARGET_COUNT) {
                    const source = dummy[idx % dummy.length];
                    const variationIndex = Math.floor(mapped.length / dummy.length);
                    const dto = mapDummyToCreateDto(source, variationIndex);
                    dto.title = `${dto.title} ${mapped.length + 1}`;
                    mapped.push(dto);
                    idx++;
                }
                logger.log(`Prepared ${mapped.length} product DTOs, inserting in batches...`);
                await batchInsert(productsService, mapped);
                logger.log(`Seeded ${mapped.length} products.`);
            }
        }
        else {
            logger.log('Products exist, skipping product seed');
        }
        const seedAdminEmail = 'admin@example.com';
        const seedAdminPassword = 'adminpass';
        const created = await usersService.ensureAdminUser(seedAdminEmail, seedAdminPassword, parseInt(process.env.BCRYPT_SALT_ROUNDS || '10', 10));
        if (created) {
            logger.log(`Created admin user: ${seedAdminEmail}`);
        }
        else {
            logger.log('Users exist, skipping admin seed');
        }
    }
    catch (err) {
        logger.error('Seeding failed', err.stack || err);
    }
    finally {
        await app.close();
    }
}
seed().catch((e) => {
    console.error(e);
    process.exit(1);
});
//# sourceMappingURL=seed.js.map