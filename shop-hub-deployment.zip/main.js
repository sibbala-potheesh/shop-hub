"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
require("reflect-metadata");
const core_1 = require("@nestjs/core");
const path_1 = require("path");
const app_module_1 = require("./app.module");
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const winston_logger_service_1 = require("./common/logger/winston-logger.service");
const error_interceptor_1 = require("./common/interceptors/error.interceptor");
const logging_interceptor_1 = require("./common/interceptors/logging.interceptor");
const roles_guard_1 = require("./common/guards/roles.guard");
const core_2 = require("@nestjs/core");
async function bootstrap() {
    const logger = new common_1.Logger('Bootstrap');
    const app = await core_1.NestFactory.create(app_module_1.AppModule, {
        logger: false,
    });
    const winstonLogger = app.get(winston_logger_service_1.WinstonLogger);
    app.useLogger(winstonLogger);
    app.enableCors();
    app.setGlobalPrefix('api');
    app.useGlobalPipes(new common_1.ValidationPipe({
        whitelist: true,
        transform: true,
        forbidNonWhitelisted: false,
    }));
    app.useGlobalInterceptors(new error_interceptor_1.ErrorInterceptor(winstonLogger));
    app.useGlobalInterceptors(new logging_interceptor_1.LoggingInterceptor(winstonLogger));
    app.useGlobalGuards(new roles_guard_1.RolesGuard(app.get(core_2.Reflector)));
    try {
        const swaggerConfig = new swagger_1.DocumentBuilder()
            .setTitle('API')
            .setDescription('API documentation')
            .setVersion('1.0')
            .addBearerAuth()
            .build();
        const document = swagger_1.SwaggerModule.createDocument(app, swaggerConfig, {
            ignoreGlobalPrefix: false,
        });
        swagger_1.SwaggerModule.setup('api/docs', app, document);
        logger.log('Swagger initialized at /api/docs');
    }
    catch (err) {
        logger.error('Swagger generation failed:', err.message);
        logger.debug(err.stack || '');
    }
    const publicPath = (0, path_1.resolve)(process.env.ROOT_LOCATION || '', '.', 'public');
    app.useStaticAssets(publicPath);
    console.log(`Serving static assets from: ${publicPath}`);
    console.log(process.env.ROOT_LOCATION);
    logger.log(`Serving static assets from: ${publicPath}`);
    app
        .getHttpAdapter()
        .getInstance()
        .get('*', (req, res, next) => {
        const url = req.url;
        if (url.startsWith('/api') ||
            url.startsWith('/static') ||
            url.startsWith('/static-images') ||
            url.startsWith('/static-profile') ||
            url.startsWith('/uploads')) {
            return next();
        }
        res.sendFile((0, path_1.join)(publicPath, 'index.html'));
    });
    await app.init();
    logger.log('App initialized');
    const port = process.env.PORT || 3000;
    await app.listen(port);
    winstonLogger.log(`Application listening on port ${port}`, 'Bootstrap');
}
bootstrap().catch((err) => {
    console.error('Bootstrap fatal error', err);
    process.exit(1);
});
//# sourceMappingURL=main.js.map