"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.isValidObjectId = isValidObjectId;
const mongoose_1 = require("mongoose");
function isValidObjectId(id) {
    return mongoose_1.default.Types.ObjectId.isValid(id);
}
//# sourceMappingURL=mongoose.utils.js.map