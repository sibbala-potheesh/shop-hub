export declare function isValidObjectId(id: any): boolean;
